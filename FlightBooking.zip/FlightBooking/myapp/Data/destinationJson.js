db.destination.insert([
{
	airportID: 'A001',
	airportName: 'Netaji Subhas Int. Airport',
	cityName: 'Kolkata',
	category: 4
},
{
	airportID: 'A002',
	airportName: 'Kempagowda Intl. Airport',
	cityName: 'Bengaluru',
	category: 5
},
{
	airportID: 'A003',
	airportName: 'Chennai Intl. Airport',
	cityName: 'Chennai',
	category: 4
},
{
	airportID: 'A004',
	airportName: 'Indra Gandhi Intl. Airport',
	cityName: 'New Delhi',
	category: 5
},
{
	airportID: 'A005',
	airportName: 'Delhi Domestic Airport',
	cityName: 'New Delhi',
	category: 3
},
{
	airportID: 'A007',
	airportName: 'Chhatrapati Shivaji Intl. Airport',
	cityName: 'Mumbai',
	category: 5
},
{
	airportID: 'A008',
	airportName: 'Chhatrapati Shivaji Domestic Airport',
	cityName: 'Mumbai',
	category: 3
},
{
	airportID: 'A009',
	airportName: 'Juhu Airport',
	cityName: 'Mumbai',
	category: 3
}
])