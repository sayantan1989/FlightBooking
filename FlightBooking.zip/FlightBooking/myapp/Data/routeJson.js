db.route.insert([
{
	routeID: 'R001',
	sourceAirportID: 'A001',
	targetAirportID: 'A002',
	distance: 2100
},
{
	routeID: 'R002',
	sourceAirportID: 'A002',
	targetAirportID: 'A001',
	distance: 2150
},
{
	routeID: 'R003',
	sourceAirportID: 'A002',
	targetAirportID: 'A003',
	distance: 310
},
{
	routeID: 'R004',
	sourceAirportID: 'A003',
	targetAirportID: 'A002',
	distance: 300
},
{
	routeID: 'R005',
	sourceAirportID: 'A002',
	targetAirportID: 'A004',
	distance: 1800
},
{
	routeID: 'R007',
	sourceAirportID: 'A004',
	targetAirportID: 'A002',
	distance: 1850
},
{
	routeID: 'R008',
	sourceAirportID: 'A002',
	targetAirportID: 'A007',
	distance: 1200
},
{
	routeID: 'R009',
	sourceAirportID: 'A007',
	targetAirportID: 'A002',
	distance: 1210
}
])