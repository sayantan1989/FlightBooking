db.airlines.insert([
{
	airlineID: 'P001',
	airlineName: 'Spice Jet',	
},
{
	airlineID: 'P002',
	airlineName: 'Indigo',
},
{
	airlineID: 'P003',
	airlineName: 'Air India',
},
{
	airlineID: 'P004',
	airlineName: 'Vistara',
}
])