const express = require('express');
const mongoose = require('mongoose');
const {MongoClient} = require('mongodb');

const bodyParser = require('body-parser');
const ObjectId = require("mongodb").ObjectID;
const CONNECTION_URL = "mongodb+srv://mongo_scs20:mongoscs2020@cluster0.bl1yv.mongodb.net/test?retryWrites=true";
const DATABASE_NAME = "FlightBookingAPI";

const app = express();
const port = process.env.PORT || 3000;

MongoClient.connect(CONNECTION_URL, { useNewUrlParser: true }, (error, client) => {
  if(error) {
    throw error;
  }
  database = client.db(DATABASE_NAME);
  console.log("Connected to `" + DATABASE_NAME + "`!");
  destination = database.collection("destination");
  airlines = database.collection("airlines");
});

const airlineRouter = require('./routeController/airlineController')();
app.use('/home',airlineRouter);

const destinationRouter = require('./routeController/destinationController')();
app.use('/home',destinationRouter);

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

//  using express get to navigate to page
app.get('/', (req, res) => {
  res.send('Welcome to Homepage of Flight booking');
});

app.listen(port, () => {
  console.log(`Running on port ${port}`);
});
