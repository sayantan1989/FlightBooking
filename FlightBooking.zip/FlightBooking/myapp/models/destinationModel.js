const mongoose = require('mongoose');

const { Schema } = mongoose;

const destinationModel = new Schema(
  {
    airportID: { type: String },
    airportName: { type: String },
    cityName: { type: String },
    category: { type: Integer },
  }
);

module.exports = mongoose.model('Book', destinationModel);
