const mongoose = require('mongoose');

// destructure Schema from Mongoose
const { Schema } = mongoose;

// schema and atributes should match collection Airlines
const airlinesModel = new Schema(
  {
    airportID: { type: String },
    airlineName: { type: String },
  }
);

// <Airlines> is the collection name in the DB
module.exports = mongoose.model('Airlines', airlinesModel);
