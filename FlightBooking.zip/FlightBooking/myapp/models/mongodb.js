const mongoose = require('mongoose');
const opt = {
    authSource: 'admin',
    replicaSet: 'replicaset',
    useNewUrlParser: true
}
const uri = 'mongodb://mongo_scs20:mongoscs2020@cluster0.bl1yv.mongodb.net:27017/FlightBookingAPI';

mongoose.connect(uri, opt).then(function () {
    console.log('Mongodb connect success!')
}, function (err) {
    console.log('Mongodb connect error: ', err)
}) 
