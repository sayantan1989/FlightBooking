const mongoose = require('mongoose');

const { Schema } = mongoose;

const routeModel = new Schema(
  {
    routeID: { type: String },
    sourceAirportID: { type: String },
    targetAirportID: { type: String },
    distance: { type: Integer },
  }
);

module.exports = mongoose.model('Book', routeModel);
