const express = require('express');
const mongoose = require('mongoose');

//const Airline = require('./models/airlinesModel.js');


function routes(){
  const airlineRouter = express.Router();
  //option 1-using router to navigate to a page
  // to support query param ex : http://localhost:3000/home/airlines?airlineID=P001
  airlineRouter.route('/airlines')

  /*
    .post((req, res) => {
        const airline = new Airline(req.body);
        airline.save();
        return res.status(201).json(airline);
      })*/

  .get((req,res) => {
    const query = {};
    // to validate query params, fill query only if req has param airlineID or airlineName
    if (req.query.airlineID) {
      query.airlineID = req.query.airlineID;
    }
    if (req.query.airlineName) {
      query.airlineName = req.query.airlineName;
    }
    //query db and send result
    airlines.find(query).toArray((err,airlinesData) => {
      if(err){
        return res.send(err);
      }
      return res.json(airlinesData);
    });
  });

  // to suppor query by ID ex : http://localhost:3000/home/airlines/5f704c17148574869784751b
  airlineRouter.route('/airlines/:airlineID') // has to be same id an in DB
  .get((req, res) => {
    airlines.findById(req.params.airlineID).toArray((err, airlinesData) => {
      if (err) {
        return res.send(err);
      }
      return res.json(airlinesData);
    });
  });




  return airlineRouter;
}


module.exports = routes;
