const express = require('express');
const mongoose = require('mongoose');

function routes(){
  const destinationRouter = express.Router();
  destinationRouter.route('/destination')
  .get((req, res) => {
    destination.find({}).toArray((error, result) => {
      if(error) {
        return res.status(500).send(error);
      }
      res.send(result);
    });
  });
  return destinationRouter;
}
  module.exports = routes;
